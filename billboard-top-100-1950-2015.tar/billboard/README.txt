These are the Billboard end-of-year charts from 1950 - 2015. Each file has chart position, artist, and song title.

The data was scraped from http://www.bobborst.com/popculture/top-100-songs-of-the-year/?year=2015.

NOTE: for 1950-1955, there are only the top 30 songs on that site.


